package com.loantable.loantable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoantableApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoantableApplication.class, args);
	}

}
