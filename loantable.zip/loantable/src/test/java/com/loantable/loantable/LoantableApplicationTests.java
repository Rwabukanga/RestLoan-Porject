package com.loantable.loantable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoantableApplicationTests {

	@Test
	void contextLoads() {
	}

}
